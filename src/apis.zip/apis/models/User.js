import Model from "./Model";


export default  {
    ...Model,
    first_name: '',
    last_name: '',
    email: '',
    password: '',
    confirm_password: '',
    phone: '',
    website: '',
    successMsg: '',
    errorMsg: '',
}
