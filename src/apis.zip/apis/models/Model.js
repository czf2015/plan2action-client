export default {
    id: Math.random(),
    createdAt: Date.now(),
    modifiedAt: Date.now()
};
