import Model from './Model'


export default {
    ...Model,
    username: '',
    password: ''
}
